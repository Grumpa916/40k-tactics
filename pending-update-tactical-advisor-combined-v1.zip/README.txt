40K Tactics Tactical Advisor — Combined Patch v1

Upload pending-update.mjs to the root of the GitLab repository, replacing any older pending-update.mjs.
Do not upload the earlier tactical-advisor-mission-threat-v1 package; this package supersedes it.

Expected pipeline marker:
UPDATE_VERSION tactical-advisor-combined-v1

The updater:
- adds modular objective/Primary, secondary, and recorded-threat advisory layers
- adds a stable Compare Your Targets view model
- exposes expected damage, chance to meet/exceed expected damage, destruction chance, Primary impact, Secondary impact, and recent threat
- uses verified active secondary rules for ranking; unverified active cards are shown as unresolved rather than silently weighted
- does not award VP or make approximate map distances authoritative
- preserves the existing Shooting target resolver and only replaces the Shooting Advisor presentation function
