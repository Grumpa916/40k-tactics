40K Tactics — Tabletop UI iPad Fit v2

STATUS: Ready for test deployment. This supersedes tabletop-ui-experiment-v1.
DO NOT deploy the Tactical Advisor staged-v2 HOLD package yet.

Upload only pending-update.mjs to the GitLab repository root.
Expected pipeline marker:
  UPDATE_VERSION tabletop-ui-ipad-fit-v2

After the pipeline is green, open:
  https://40k-tactics.pages.dev/battle.html?ui=tabletop

Classic fallback:
  https://40k-tactics.pages.dev/battle.html?ui=classic

Changes:
- Constrains the tabletop battle shell to the iPad Safari landscape viewport.
- Keeps the full top battle context inside a compact header.
- Uses remaining vertical space for the map-left / controls-right workspace.
- Keeps bottom army dock visible.
- Keeps Tactical Advisor detail scrolling inside the right panel.
- Prevents page-level scrolling in landscape tabletop mode.
- Preserves the classic layout and does not include staged Tactical Advisor v2.
