import { BATTLE_STATUS } from "../state/battle.js";
import { UNIT_STATUS } from "../state/unit.js";
import { PHASES, TURN_STEPS } from "../state/turn.js";
import { createEvent } from "../events/event.js";
import { appendHistoryEntry } from "../state/history.js";
import { getFightCandidates } from "../rules/fight-candidates.js";
import { getShootingCandidates } from "../rules/shooting-candidates.js";
import { createObjectiveState } from "../rules/objective-control-state.js";
import { captureTurnStartSnapshot } from "./scoring-transitions.js";
import { updateTurnClockForPlayer } from "../state/turn-clock.js";
import { pauseTurnClock, startTurnClock } from "./turn-clock-transitions.js";

function transition(state, eventType, payload, apply) {
  const nextState = apply(state);
  return appendHistoryEntry(nextState, createEvent(eventType, payload));
}

export function startBattle(state, { battleId, missionId = null } = {}) {
  if (!battleId) throw new TypeError("Battle id is required.");
  if (state.battle) throw new Error("A battle already exists.");
  return transition(state, "battle.started", { battleId, missionId }, (current) => ({
    ...current,
    phase: "deployment",
    battle: {
      id: battleId,
      missionId,
      status: BATTLE_STATUS.DEPLOYMENT,
      round: 0,
      activePlayerId: null,
      firstPlayerId: null
    },
    timers: {
      ...(current.timers ?? {}),
      turnClock: { elapsedMsByPlayer: {}, activePlayerId: null, running: false, startedAtMs: null }
    }
  }));
}

export function enterDeployment(state) {
  if (!state.battle || state.battle.status !== BATTLE_STATUS.SETUP) {
    throw new Error("Battle must be in setup before deployment.");
  }
  return transition(state, "battle.deployment_started", {}, (current) => ({
    ...current,
    phase: "deployment",
    battle: { ...current.battle, status: BATTLE_STATUS.DEPLOYMENT }
  }));
}

export function deployUnit(state, { unitId, position } = {}) {
  if (!unitId) throw new TypeError("Unit id is required.");
  if (!state.battle || state.battle.status !== BATTLE_STATUS.DEPLOYMENT) {
    throw new Error("Battle must be in deployment.");
  }
  const unit = state.units.find((item) => item.id === unitId);
  if (!unit) throw new Error("Unit not found: " + unitId);
  if (unit.status !== UNIT_STATUS.RESERVES) {
    throw new Error("Unit must be in reserves before deployment.");
  }
  return transition(state, "unit.deployed", { unitId, position }, (current) => ({
    ...current,
    units: current.units.map((item) =>
      item.id === unitId
        ? { ...item, status: UNIT_STATUS.DEPLOYED, position: position ?? item.position }
        : item
    )
  }));
}

function requirePlayer(state, playerId) {
  if (!playerId) throw new TypeError("An active player is required.");
  if (state.players.length > 0 && !state.players.some((player) => player.id === playerId)) {
    throw new Error("Active player must exist in the game state.");
  }
}

export function recordObjectiveControl(state, {
  objectiveId,
  controllerId = null,
  contestingPlayerIds = [],
  controlState = null
} = {}) {
  if (!objectiveId) throw new TypeError("Objective id is required.");
  if (!Array.isArray(contestingPlayerIds)) {
    throw new TypeError("contestingPlayerIds must be an array.");
  }

  const objective = state.objectives.find((item) => item?.id === objectiveId);
  if (!objective) throw new Error("Objective not found: " + objectiveId);

  for (const playerId of contestingPlayerIds) requirePlayer(state, playerId);
  if (controllerId) requirePlayer(state, controllerId);

  const control = createObjectiveState({
    id: objectiveId,
    controllerId,
    contestingPlayerIds,
    controlState
  });

  return transition(state, "objective.control_recorded", control, (current) => ({
    ...current,
    objectives: current.objectives.map((item) =>
      item.id === objectiveId ? { ...item, control } : item
    )
  }));
}

export function startFirstTurn(state, { activePlayerId, nowMs = Date.now() } = {}) {
  requirePlayer(state, activePlayerId);
  if (!state.battle || state.battle.status !== BATTLE_STATUS.DEPLOYMENT) {
    throw new Error("Battle must be in deployment before the first turn.");
  }

  const roundStarted = transition(state, "battle.round_started", {
    round: 1,
    firstPlayerId: activePlayerId
  }, (current) => ({
    ...current,
    phase: "start_battle_round",
    battle: {
      ...current.battle,
      status: BATTLE_STATUS.ACTIVE,
      round: 1,
      activePlayerId: null,
      firstPlayerId: activePlayerId
    }
  }));

  const turnStarted = transition(roundStarted, "turn.started", { number: 1, activePlayerId }, (current) => ({
    ...current,
    phase: "start_turn",
    turn: 1,
    activePlayer: activePlayerId,
    battle: { ...current.battle, activePlayerId }
  }));

  const withTurnSnapshot = captureTurnStartSnapshot(turnStarted, {
    turn: 1,
    round: 1,
    playerId: activePlayerId
  });
  const clock = withTurnSnapshot.timers?.turnClock ?? {};
  return {
    ...withTurnSnapshot,
    timers: {
      ...(withTurnSnapshot.timers ?? {}),
      turnClock: {
        elapsedMsByPlayer: { ...(clock.elapsedMsByPlayer ?? {}) },
        activePlayerId,
        running: true,
        startedAtMs: nowMs
      }
    }
  };
}

export function changePhase(state, { phase } = {}) {
  if (![...TURN_STEPS, "end_battle_round", "start_battle_round"].includes(phase)) {
    throw new RangeError("Unknown turn step or phase: " + phase);
  }
  if (!state.battle || state.battle.status !== BATTLE_STATUS.ACTIVE) {
    throw new Error("Battle must be active.");
  }
  const phaseIndex = TURN_STEPS.indexOf(state.phase);
  const nextPhase = TURN_STEPS[phaseIndex + 1];
  if (phaseIndex < 0 || phase !== nextPhase) {
    throw new Error("Turn steps must resolve in order.");
  }
  if (state.phase === "command") {
    const activePlayerId = state.activePlayer ?? state.battle?.activePlayerId;
    const pendingRedraw = state.scoring?.secondaryMissionRedrawPendingByPlayer?.[activePlayerId];
    if (pendingRedraw && pendingRedraw.round === (state.battle?.round ?? 0) &&
        pendingRedraw.turn === (state.turn ?? 0)) {
      throw new Error("Record the New Orders replacement card before leaving the Command phase.");
    }
  }

  const isShootingCompletion = state.phase === "shooting" && phase === "charge";
  if (isShootingCompletion) {
    const candidates = getShootingCandidates(state);
    if (candidates.available.length > 0) {
      throw new Error("Shooting phase cannot be completed while eligible units remain.");
    }

    const completed = transition(state, "shooting.phase_completed", {
      round: state.battle.round,
      turn: state.turn
    }, (current) => current);

    return transition(completed, "turn.phase_changed", {
      phase,
      round: state.battle.round,
      turn: state.turn
    }, (current) => ({
      ...current,
      phase
    }));
  }

  const isFightCompletion = state.phase === "fight" && phase === "end_turn";
  if (isFightCompletion) {
    const candidates = getFightCandidates(state);
    if (candidates.fightsFirst.length > 0 || candidates.normal.length > 0) {
      throw new Error("Fight phase cannot be completed while Fight candidates remain.");
    }

    const completed = transition(state, "fight.phase_completed", {
      round: state.battle.round,
      turn: state.turn
    }, (current) => current);

    return transition(completed, "turn.phase_changed", {
      phase,
      round: state.battle.round,
      turn: state.turn
    }, (current) => ({
      ...current,
      phase
    }));
  }

  return transition(state, "turn.phase_changed", {
    phase,
    round: state.battle.round,
    turn: state.turn
  }, (current) => ({
    ...current,
    phase
  }));
}

export function endTurn(state, { nextActivePlayerId, nowMs = Date.now() } = {}) {
  if (!state.battle || state.battle.status !== BATTLE_STATUS.ACTIVE) {
    throw new Error("Battle must be active.");
  }
  if (state.phase !== "end_turn") {
    throw new Error("The turn must reach its end step before it can end.");
  }
  requirePlayer(state, nextActivePlayerId);
  if (nextActivePlayerId === state.activePlayer) {
    throw new Error("The next turn must belong to the other player.");
  }
  if (state.players.length === 2) {
    const opponent = state.players.find((player) => player.id !== state.activePlayer);
    if (nextActivePlayerId !== opponent?.id) {
      throw new Error("The next turn must belong to the opponent.");
    }
  }
  if (!state.battle.firstPlayerId) {
    throw new Error("The first player for this battle round is not set.");
  }

  const battleRoundComplete = nextActivePlayerId === state.battle.firstPlayerId;
  const ended = transition(state, "turn.ended", {
    playerId: state.activePlayer,
    nextActivePlayerId,
    turn: state.turn,
    battleRoundComplete
  }, (current) => ({
    ...current,
    phase: battleRoundComplete ? "end_battle_round" : "start_turn",
    turn: battleRoundComplete ? current.turn : current.turn + 1,
    activePlayer: battleRoundComplete ? null : nextActivePlayerId,
    battle: {
      ...current.battle,
      activePlayerId: battleRoundComplete ? null : nextActivePlayerId
    }
  }));

  const withTurnClock = battleRoundComplete
    ? pauseTurnClock(ended, { nowMs })
    : updateTurnClockForPlayer(ended, nextActivePlayerId, nowMs);
  return battleRoundComplete
    ? transition(withTurnClock, "battle.round_ended", { round: state.battle.round }, (current) => current)
    : withTurnClock;
}

export function advanceBattleRound(state, { nowMs = Date.now() } = {}) {
  if (!state.battle || state.battle.status !== BATTLE_STATUS.ACTIVE) {
    throw new Error("Battle must be active.");
  }
  if (state.phase !== "end_battle_round") {
    throw new Error("Both players must finish their turns before the battle round can end.");
  }
  if (!state.battle.firstPlayerId) {
    throw new Error("The first player for this battle round is not set.");
  }

  const roundStarted = transition(state, "battle.round_started", {
    round: state.battle.round + 1,
    firstPlayerId: state.battle.firstPlayerId
  }, (current) => ({
    ...current,
    phase: "start_battle_round",
    activePlayer: null,
    battle: {
      ...current.battle,
      round: current.battle.round + 1,
      activePlayerId: null
    }
  }));

  const turnNumber = state.turn + 1;
  const turnStarted = transition(roundStarted, "turn.started", {
    number: turnNumber,
    activePlayerId: state.battle.firstPlayerId
  }, (current) => ({
    ...current,
    phase: "start_turn",
    turn: turnNumber,
    activePlayer: current.battle.firstPlayerId,
    battle: { ...current.battle, activePlayerId: current.battle.firstPlayerId }
  }));

  const withTurnSnapshot = captureTurnStartSnapshot(turnStarted, {
    turn: turnNumber,
    round: state.battle.round + 1,
    playerId: state.battle.firstPlayerId
  });
  const withTurnClock = updateTurnClockForPlayer(withTurnSnapshot, state.battle.firstPlayerId, nowMs);
  return withTurnClock.timers?.turnClock?.running
    ? withTurnClock
    : startTurnClock(withTurnClock, { nowMs });
}

export function completeBattle(state, { nowMs = Date.now() } = {}) {
  if (!state.battle || state.battle.status !== BATTLE_STATUS.ACTIVE) {
    throw new Error("Battle must be active before completion.");
  }
  if (!Number.isFinite(nowMs)) throw new TypeError("A valid clock timestamp is required.");
  const completed = transition(state, "battle.completed", {}, (current) => ({
    ...current,
    phase: "complete",
    battle: { ...current.battle, status: BATTLE_STATUS.COMPLETE }
  }));
  return pauseTurnClock(completed, { nowMs });
}
